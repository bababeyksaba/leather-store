export default { skipTrailingSlashRedirect: true };
